#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

start python:
    python3

execute script:
    exec(open("plot_time_series.py").read())


"""
import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
import datetime
import matplotlib.dates as mdates

jobname = 'e5_wtm_exercise'
ID='.000'   # the cycle number of the run e.g. '.000', '.001', ...

path = '~/palm/v25.04/JOBS/'+jobname+'/OUTPUT/'

print(jobname+ID)

# read time series:
fname_ts = path+jobname+'_ts'+ID+'.nc'
ds_ts = xr.open_dataset(fname_ts)

###############################################################################
# plotting

plt.close('all')

# plot total Energy E
fig = plt.figure()
ax = fig.add_axes([0.12,0.12,0.8,0.75])
ax.plot(ds_ts.time.values.astype(np.datetime64),ds_ts.E,'k-')
#ax.set_xlim(['1970-01-01T00:00:00.0','1970-01-01T02:00:00.0'])
#ax.set_xlim(['1970-01-03T22:00:00.0','1970-01-04T00:00:00.0'])
#ax.set_ylim([56.8,57.1])
ax.grid()
ax.set_xlabel(r'$t$ (HH:SS)')
ax.set_ylabel(r'$E$ ($\mathrm{m^2 s^{-2}}$)')
ax.set_title(jobname+ID+'\nTotal kinetic energy (3d domain average) E')

ax.xaxis.set_major_locator(mdates.HourLocator())
ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
ax.xaxis.set_minor_formatter(mdates.DateFormatter("%H:%M"))

# plot averaged resolved turbulent kinetic Energy E*
fig = plt.figure()
ax = fig.add_axes([0.12,0.12,0.8,0.75])
ax.plot(ds_ts.time.values.astype(np.datetime64),ds_ts['E*'],'k-')
ax.set_ylim([0,1.2*ds_ts['E*'].isel(time=-1)])
ax.grid()    
ax.set_xlabel(r'$t$ (HH:SS)')
ax.set_ylabel(r'$E*$ ($\mathrm{m^2 s^{-2}}$)')
ax.set_title(jobname+ID+'\nResolved scale turbulent kinetic Energy (3d domain average) E*')
ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
ax.xaxis.set_minor_formatter(mdates.DateFormatter("%H:%M"))
plt.show()
