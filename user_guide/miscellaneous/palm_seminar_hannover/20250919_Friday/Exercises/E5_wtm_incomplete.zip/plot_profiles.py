#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

start python:
    python3

execute script:
    exec(open("plot_profiles.py").read())

"""
#from netCDF4 import Dataset
#import pandas as pd
import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable


jobname = 'e5_wtm_exercise'
ID='.000'   # the cycle number of the run e.g. '.000', '.001', ...

path = '~/palm/v25.04/JOBS/'+jobname+'/OUTPUT/'

print(jobname+ID)

#time_id = -1        # evaluate last output (index = -1)
z_hub = 150
D = 240      # rotor diameter in m
R = D/2
z_b = z_hub-D/2
z_t = z_hub+D/2

# read profiles:
fname_pr = path+jobname+'_pr'+ID+'.nc'
ds_pr = xr.open_dataset(fname_pr)

# calculate wind speed and direction
ds_pr['u'] = ds_pr['u'].rename({'zu':'z'})
ds_pr['v'] = ds_pr['v'].rename({'zv':'z'})
ds_pr['ws'] = (ds_pr['u']**2 + ds_pr['v']**2 )**(0.5)
ds_pr['wd'] = -np.arctan2(ds_pr['v'],ds_pr['u'])*180/np.pi # defined clockwise positive

###############################################################################
# plotting

plt.close('all')


# plot profiles:
ymax = float(ds_pr.z.max())
# create list of output indices with regular step size
step_pr = 1             # use every step_pr profile output
# number of plotted profile outputs:
#      (n_intervals        )          include first and last output step
n_pr = (len(ds_pr.time) - 1)//step_pr + 1  
i_pr = np.arange(0,len(ds_pr.time),step_pr)

# create list of time strings for legend entries:
time_string = ['']*n_pr
for i in range(n_pr):
    time_string[i] = str(np.datetime64(int(ds_pr.time.isel(time=i_pr[i]).values), 'ns'))[11:16]

markers = ['o','^','v','+','x','s','<','>','*'] #'v','<','s','x','+','*','1','2','3']

# plot wind speed profile
fig = plt.figure()
ax = fig.add_axes([0.12,0.12,0.8,0.75])
m=0
for i in i_pr:
    ax.plot(ds_pr['ws'].isel(time=i),ds_pr['z'],marker=markers[m])
    m=m+1
ax.plot([0,30],[z_b,z_b],'k--')
ax.plot([0,30],[z_hub,z_hub],'k--')
ax.plot([0,30],[z_t,z_t],'k--')
ax.set_xlim([0,15])
ax.set_ylim([0,ymax])
ax.grid()
ax.set_xlabel(r'Wind speed (m s$^{-1}$)')
ax.set_ylabel(r'$z$ (m)')
ax.set_title(jobname+ID)
ax.legend(time_string)

# plot wind direction profile
fig = plt.figure()
ax = fig.add_axes([0.12,0.12,0.8,0.75])
m=0
for i in i_pr:
    ax.plot(ds_pr['wd'].isel(time=i),ds_pr['z'],marker=markers[m])
    m=m+1
ax.plot([-45,45],[z_b,z_b],'k--')
ax.plot([-45,45],[z_hub,z_hub],'k--')
ax.plot([-45,45],[z_t,z_t],'k--')
ax.set_xlim([-30,30])
ax.set_ylim([0,ymax])
ax.grid()
ax.set_xlabel(r'Wind direction (degrees)')
ax.set_ylabel(r'$z$ (m)')
ax.set_title(jobname+ID)
ax.legend(time_string)

# plot wu flux profile
fig = plt.figure()
ax = fig.add_axes([0.12,0.12,0.8,0.75])
ax.plot(ds_pr['wu'].isel(time=-1),ds_pr['z'],marker=markers[3])
ax.plot([-45,45],[z_b,z_b],'k--')
ax.plot([-45,45],[z_hub,z_hub],'k--')
ax.plot([-45,45],[z_t,z_t],'k--')
ax.set_xlim([-0.3,0.03])
ax.set_ylim([0,ymax])
ax.grid()
ax.set_xlabel(r'Momentum flux $\mathrm{\overline{w^\prime u^\prime}}$ (m s$^{-1}$)')
ax.set_ylabel(r'$z$ (m)')
ax.set_title(jobname+ID)
ax.legend([time_string[-1]])

plt.show()
