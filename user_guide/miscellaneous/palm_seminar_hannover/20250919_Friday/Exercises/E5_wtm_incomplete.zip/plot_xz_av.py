#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

start python:
    python3

execute script:
    exec(open("plot_xz_av.py").read())

"""
import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable


jobname = 'e5_wtm_exercise'
ID='.000'   # the cycle number of the run e.g. '.000', '.001', ...

path = '~/palm/v25.04/JOBS/'+jobname+'/OUTPUT/'

print(jobname+ID)

time_id = -1        # evaluate last averaging period (index = -1)
z_hub = 150
D = 240      # rotor diameter in m
R = D/2

# read average xy
fname_av_3d = path+jobname+'_av_3d'+ID+'.nc'
ds_av_3d = xr.open_dataset(fname_av_3d)

duration_av_3d = str(np.datetime64(int(ds_av_3d.time.isel(time=time_id).values), 'ns'))[11:16]

# read wind turbine data
fname_wtm = path+jobname+'_wtm'+ID+'.nc'
ds_wtm = xr.open_dataset(fname_wtm)

hub_x = ds_wtm['x']
hub_y = ds_wtm['y']
hub_z = ds_wtm['z']

y1 = hub_y[0]

###############################################################################
# plotting

plt.close('all')

# plot averaged wind speed
fig = plt.figure()
ax = fig.add_axes([0.12,0.12,0.7,0.75])
var = ds_av_3d['wspeed'].isel(time=time_id).interp(y=y1,method='linear')
c = ax.pcolormesh(var.x,var.zu_3d,var,cmap='inferno',vmin=2.0, vmax=12.0,shading='gouraud')
divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size=0.1, pad=0.05)
plt.colorbar(c,cax=cax,label=r'Average wind speed $\overline{v}_h$ (m s$^{-1}$)')
ax.set_title(jobname+ID+', wspeed_av_xz, y = {:03.1f}'.format(
        np.array(y1))+' m, t = '+duration_av_3d+' h')
ax.set_xlabel(r'$x$ (m)')
ax.set_ylabel(r'$z$ (m)')
ax.set_aspect('equal', 'box')
# plot rotors:
for wt in range(len(hub_x)):
    ax.plot([hub_x[wt],hub_x[wt]],[hub_z[wt]-R,hub_z[wt]+R],'w-')

# plot averaged v-component
fig = plt.figure()
ax = fig.add_axes([0.12,0.12,0.7,0.75])
var = ds_av_3d['v'].isel(time=time_id).interp(yv=y1,method='linear')
c = ax.pcolormesh(var.x,var.zu_3d,var,cmap='RdBu_r',vmin=-0.5, vmax=0.5,shading='gouraud')
divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size=0.1, pad=0.05)
plt.colorbar(c,cax=cax,label=r'$\overline{v}$ (m s$^{-1}$)')
ax.set_title(jobname+ID+', v_av_xz, y = {:03.1f}'.format(
        np.array(y1))+' m, t = '+duration_av_3d+' h')
ax.set_xlabel(r'$x$ (m)')
ax.set_ylabel(r'$z$ (m)')
ax.set_aspect('equal', 'box')
# plot rotors:
for wt in range(len(hub_x)):
    ax.plot([hub_x[wt],hub_x[wt]],[hub_z[wt]-R,hub_z[wt]+R],'w-')

# plot averaged vertical wind speed w
fig = plt.figure()
ax = fig.add_axes([0.12,0.12,0.7,0.75])
var = ds_av_3d['w'].isel(time=time_id).interp(y=y1,method='linear')
c = ax.pcolormesh(var.x,var.zw_3d,var,cmap='RdBu_r',vmin=-0.5, vmax=0.5,shading='gouraud')
divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size=0.1, pad=0.05)
plt.colorbar(c,cax=cax,label=r'$\overline{w}$ (m s$^{-1}$)')
ax.set_title(jobname+ID+', w_av_xz, y = {:03.1f}'.format(
        np.array(y1))+' m, t = '+duration_av_3d+' h')
ax.set_xlabel(r'$x$ (m)')
ax.set_ylabel(r'$z$ (m)')
ax.set_aspect('equal', 'box')
# plot rotors:
for wt in range(len(hub_x)):
    ax.plot([hub_x[wt],hub_x[wt]],[hub_z[wt]-R,hub_z[wt]+R],'w-')

# plot averaged SGS-TKE
fig = plt.figure()
ax = fig.add_axes([0.12,0.12,0.7,0.75])
var = ds_av_3d['e'].isel(time=time_id).interp(y=y1,method='linear')
c = ax.pcolormesh(var.x,var.zu_3d,var,cmap='inferno',vmin=0.0, vmax=0.4,shading='gouraud')
divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size=0.1, pad=0.05)
plt.colorbar(c,cax=cax,label=r'SGS TKE $\overline{e}$ (m$^{2}$ s$^{-2}$)')
ax.set_title(jobname+ID+', e_av_xz, y = {:03.1f}'.format(
        np.array(y1))+' m, t = '+duration_av_3d+' h')
ax.set_xlabel(r'$x$ (m)')
ax.set_ylabel(r'$z$ (m)')
ax.set_aspect('equal', 'box')
# plot rotors:
for wt in range(len(hub_x)):
    ax.plot([hub_x[wt],hub_x[wt]],[hub_z[wt]-R,hub_z[wt]+R],'w-')


plt.show()
