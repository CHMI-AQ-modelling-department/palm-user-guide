#------------------------------------------------------------------------------#
# This file is part of the PALM model system.
#
# PALM is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later
# version.
#
# PALM is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# PALM. If not, see <http://www.gnu.org/licenses/>.
#
# Copyright 1997-2020 Leibniz Universitaet Hannover
#------------------------------------------------------------------------------#

import math
import netCDF4
from   netCDF4 import Dataset
import numpy as np
import datetime


class StaticDriver:
    """ This is an example script to generate static drivers for PALM.

    You can use it as a starting point for creating your setup specific
    driver.
    """


    def __init__(self):
        """ Open the static driver as NetCDF4 file. Here, you have to give the
        full path to the static driver that shall be created. Existing file
        with same name is deleted.
        """
        print('Opening file...')
        self.nc_file = Dataset("non_cyclic_static", 'w', format='NETCDF4')


    def write_global_attributes(self):
        """ Write global attributes to static driver. """
        print("Writing global attributes...")

        # mandatory global attributes
        self.nc_file.origin_lon = 55.0 # used to initialize coriolis parameter
        self.nc_file.origin_lat = 0.0 # (overwrite initialization_parameters)
        self.nc_file.origin_time = '2022-09-14 00:00:00 +00'
        self.nc_file.origin_x = 308124
        self.nc_file.origin_y = 6098908
        self.nc_file.origin_z = 0.0
        self.nc_file.rotation_angle = 0.0

        # optional global attributes
        self.nc_file.author = '...'
        self.nc_file.comment = 'Miscellaneous information about the data ' \
                               'or methods to produce it.'
        self.nc_file.creation_date = str(datetime.datetime.now())
        self.nc_file.institution = 'LUH'
        self.nc_file.history = ''
        self.nc_file.palm_revision = ''
        self.nc_file.title = 'Static driver for E3'


    def define_dimensions(self):
        """ Set dimensions on which variables are defined. """
        print("Writing dimensions...")

        # specify general grid parameters
        # these values must equal those set in the initialization_parameters
        self.nx = 79
        self.ny = 39
        self.nz = 40
        self.dx = 2.0
        self.dy = 2.0
        self.dz = 2.0

        # mandatory dimensions
        self.nc_file.createDimension('x' ,self.nx+1)
        self.x = self.nc_file.createVariable('x', 'f8', ('x',))
        self.x.units = 'm'
        self.x.standard_name = 'x coordinate of cell centers'
        self.x[:] = np.arange(0,(self.nx+1)*self.dx,self.dx)

        self.nc_file.createDimension('xu', self.nx)
        self.xu = self.nc_file.createVariable('xu', 'f8', ('xu',))
        self.xu.units = 'm'
        self.xu.standard_name = 'x coordinate of cell edges'
        self.xu[:] = np.arange(self.dx/2.,self.nx*self.dx,self.dx)

        self.nc_file.createDimension('y', self.ny+1)
        self.y = self.nc_file.createVariable('y', 'f8', ('y',))
        self.y.units = 'm'
        self.y.standard_name = 'y coordinate of cell centers'
        self.y[:] = np.arange(0,(self.ny+1)*self.dy,self.dy)

        self.nc_file.createDimension('yv', self.ny)
        self.yv = self.nc_file.createVariable('yv', 'f8', ('yv',))
        self.yv.units = 'm'
        self.yv.standard_name = 'y coordinate of cell edges'
        self.yv[:] = np.arange(self.dy/2.,self.ny*self.dy,self.dy)

        # if your simulation uses a stretched vertical grid, you need to
        # modify the z and zw coordinates,
        # e.g. z_array = (...) and zw_array = (...)
        z_array = np.append(0, np.arange(self.dz/2,(self.nz+1)*self.dz,self.dz))
        self.nc_file.createDimension('z',self.nz+2)
        self.z = self.nc_file.createVariable('z', 'f8', ('z',))
        self.z.units = 'm'
        self.z.standard_name = 'z coordinate of cell centers'
        self.z[:] = z_array

        zw_array = np.arange(0,(self.nz+2)*self.dz,self.dz)
        self.nc_file.createDimension('zw', self.nz+2)
        self.zw = self.nc_file.createVariable('zw', 'f8', ('zw',))
        self.zw.units = 'm'
        self.zw.standard_name = 'z coordinate of cell edges'
        self.zw[:] = zw_array

        # optional dimensions, uncomment if needed
        #self.nc_file.createDimension('zsoil', len(zsoil_array))
        #...

        #self.nc_file.createDimension('zlad', len(zlad_array))
        #...

        #self.nc_file.createDimension('nsurface_fraction', 3)
        #...


    def add_variables(self):

        print("Writing variables...")
        fill_val_real = -9999.9
        fill_val_int8 = -127

        # topography variables
        nc_buildings_2d = self.nc_file.createVariable(
             'buildings_2d', 'f4', ('y','x'), fill_value=fill_val_real)
        nc_buildings_2d.lod = 1
        nc_buildings_2d[:,:] = fill_val_real

        nc_building_id = self.nc_file.createVariable(
            'building_id', 'i1', ('y','x'), fill_value=fill_val_int8)
        nc_building_id[:,:] = fill_val_int8

        nc_building_type = self.nc_file.createVariable(
            'building_type', 'i1', ('y','x'), fill_value=fill_val_int8)
        nc_building_type[:,:] = fill_val_int8



        ## terrain height
        nc_zt = self.nc_file.createVariable(    \
            'zt', 'f4', ('y','x'), fill_value=fill_val_real)
        nc_zt.long_name = 'orography'
        nc_zt.units = 'm'

        nc_zt[:,:] = 0.0


        # Set index ranges for buildings
        build_inds_start_x = [ 50 ]
        build_inds_end_x   = [ 69 ]

        build_inds_start_y = [10]
        build_inds_end_y   = [29]

        for i in range(0,self.nx+1):
           for j in range(0,self.ny+1):

              # Set building height
              for ii in range(0,len(build_inds_start_x)):
                 for jj in range(0,len(build_inds_start_y)):

                    if ( i >= build_inds_start_x[ii] and i <= build_inds_end_x[ii] ) and \
                       ( j >= build_inds_start_y[jj] and j <= build_inds_end_y[jj] ):

                       nc_buildings_2d[j,i] = 40.0
                       nc_building_type[j,i] = 2

                       # For each (ii,jj)-pair create an unique ID
                       nc_building_id[j,i] = ii + len(build_inds_start_x) * jj

    def finalize(self):
        """ Close file """
        print("Closing file...")

        self.nc_file.close()


if __name__ == '__main__':
    driver = StaticDriver()
    driver.write_global_attributes()
    driver.define_dimensions()
    driver.add_variables()
    driver.finalize()

